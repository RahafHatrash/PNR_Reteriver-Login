﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PNR_Reteriver.Data;
using PNR_Reteriver.Models;
public class AccountController : Controller
{
    private readonly ApplicationDbContext RhfDB;

    public AccountController(ApplicationDbContext rhfDB)
    {
        RhfDB = rhfDB;
    }

    [HttpGet]
    public IActionResult Login()
    {
        return View(new LoginViewModel());
    }

    [HttpPost]
    public async Task<IActionResult> Login(LoginViewModel model)
    {
        if (ModelState.IsValid)
        {
            // Check if the user exists and the password is correct
            var user = await RhfDB.Users.FirstOrDefaultAsync(u => u.Email == model.Email);
            if (user != null && BCrypt.Net.BCrypt.Verify(model.Password, user.HashedPassword))
            {
                // Perform login logic, e.g., set session, generate token, etc.
                return RedirectToAction("Index", "Home");
            }
            else
            {
                ModelState.AddModelError("", "Invalid email or password.");
            }
        }

        return View(model);
    }
}