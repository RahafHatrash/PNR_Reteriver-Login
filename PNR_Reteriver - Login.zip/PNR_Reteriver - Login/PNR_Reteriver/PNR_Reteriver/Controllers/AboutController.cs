﻿using Microsoft.AspNetCore.Mvc;

namespace PNR_Reteriver.Controllers
{
    public class AboutController : Controller
    {
        [HttpGet]

        public IActionResult Index()
        {
            return View("About");
        }
    }
}
