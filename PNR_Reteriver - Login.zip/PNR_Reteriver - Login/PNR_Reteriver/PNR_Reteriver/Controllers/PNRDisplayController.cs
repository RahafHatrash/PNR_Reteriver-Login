﻿using Microsoft.AspNetCore.Mvc;
using System.Net.Http;
using System.Threading.Tasks;
using System.Net.Http.Headers;
using System.Text.Json;
using System.Collections.Generic;
using System.Text;

namespace PNR_Reteriver.Controllers
{
    public class PNRDisplayController : Controller
    {
        private readonly HttpClient _httpClient;

        public PNRDisplayController(IHttpClientFactory httpClientFactory)
        {
            _httpClient = httpClientFactory.CreateClient("RapidAPI");
        }

        public IActionResult Display()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Search(string searchText)
        {
            if (string.IsNullOrEmpty(searchText))
            {
                ModelState.AddModelError("", "PNR cannot be empty.");
                return View("Display");
            }

            var requestUri = $"https://pnr-status-indian-railway.p.rapidapi.com/pnr-check/{searchText}";
            var request = new HttpRequestMessage(HttpMethod.Get, requestUri);

            request.Headers.Add("x-rapidapi-host", "pnr-status-indian-railway.p.rapidapi.com");
            request.Headers.Add("x-rapidapi-key", "d5d05f36demsh3e1b959a441645bp1f1f42jsnce6462f27034");

            try
            {
                var response = await _httpClient.SendAsync(request);
                response.EnsureSuccessStatusCode();

                var jsonString = await response.Content.ReadAsStringAsync();
                var pnrData = JsonSerializer.Deserialize<Dictionary<string, object>>(jsonString);

                // Store the data in TempData for download
                TempData["SearchResults"] = jsonString;

                // Pass the data to the view using ViewData
                ViewData["SearchResults"] = pnrData;
                return View("Display");
            }
            catch (HttpRequestException ex)
            {
                ModelState.AddModelError("", $"Error: {ex.Message}");
                return View("Display");
            }
        }

        [HttpPost]
        public IActionResult Download()
        {
            var searchResultsJson = TempData["SearchResults"] as string;
            if (string.IsNullOrEmpty(searchResultsJson))
            {
                ModelState.AddModelError("", "No search results to download.");
                return View("Display");
            }

            var pnrData = JsonSerializer.Deserialize<Dictionary<string, object>>(searchResultsJson);
            var stringBuilder = new StringBuilder();
            foreach (var item in pnrData)
            {
                stringBuilder.AppendLine($"{item.Key}: {item.Value}");
            }

            var fileName = "PNRResults.txt";
            var fileContent = Encoding.UTF8.GetBytes(stringBuilder.ToString());
            var mimeType = "text/plain";

            return File(fileContent, mimeType, fileName);
        }
    }
}