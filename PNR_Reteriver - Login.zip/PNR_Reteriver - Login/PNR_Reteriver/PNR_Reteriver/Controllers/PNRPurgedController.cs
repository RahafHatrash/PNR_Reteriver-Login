﻿using Microsoft.AspNetCore.Mvc;
using System.Net.Http;

namespace PNR_Reteriver.Controllers
{
    public class PNRPurgedController : Controller
    {
        private readonly HttpClient _httpClient;

        public PNRPurgedController(IHttpClientFactory httpClientFactory)
        {
            _httpClient = httpClientFactory.CreateClient("RapidAPI");
        }

        public IActionResult Display()
        {
            return View();
        }
    }
}