﻿using Microsoft.EntityFrameworkCore;
using PNR_Reteriver.Models;
using System.Collections.Generic;

namespace PNR_Reteriver.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<User> Users { get; set; }
    }
}